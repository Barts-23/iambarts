# iambarts
<h1 align="center">ScripBartS<img src="https://img.shields.io/badge/Version-3.0-blue.svg"></h1>

<p align="center">ScriptBartS is remodify by iamBARTX to minimize the time consumed</b></p>
<h3 align="center">Services</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Service-OpenSSH-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Dropbear-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Stunnel-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-OpenVPN-green.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Squid3-green.svg"></a>
 </p>
<h3 align="center">Commands</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Commands-menu-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-accounts-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-options-yellow.svg"></a>
  <a><img src="https://img.shields.io/badge/Commands-server-yellow.svg"></a>
 </p>

<h3 align="center">Installation</h3>
<h3 align="center">Debian9x64</h3>

<h3 align="center"><font color="blue">ALL IN ONE INSTALLER</h3></font>
<p align="center">
<b>#
</b>
</p>
