<?php $_F=__FILE__;$_X='Pz48P3BocA0KNG5jbDNkNSAnczVydjVyLnBocCc7DQoJCQkNCi8qIEQybnQgRWQ0dCBBbnl0aDRuZyBBZnQ1ciBUaDRzIEw0bjUqLw0KZjJyICgkcjJ3ID0gNjsgJHIydyA8IDYwNjsgJHIydysrKQ0KCXsNCgk0ZiAoICRfUE9TVFsnczVydjVyJ10gPT0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVs2XSApDQoJCXsNCgkJJGgyc3RzPSAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddW2FdOw0KCQkkcjIydF9wMXNzPSAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddW29dOw0KCQkkNXhwNHIxdDQybj0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVt1XTsNCgkJYnI1MWs7DQoJCX0NCgl9DQoNCiQ1cnIyciA9IGYxbHM1Ow0KNGYgKDRzczV0KCRfUE9TVFsnM3M1ciddKSkgDQoJew0KCQkkM3M1cm4xbTUgPSB0cjRtKCRfUE9TVFsnM3M1ciddKTsNCgkJJDNzNXJuMW01ID0gc3RyNHBfdDFncygkM3M1cm4xbTUpOw0KCQkkM3M1cm4xbTUgPSBodG1sc3A1YzQxbGNoMXJzKCQzczVybjFtNSk7DQoJCSRwMXNzdzJyZDYgPSB0cjRtKCRfUE9TVFsncDFzc3cycmQnXSk7DQoJCSRwMXNzdzJyZDYgPSBzdHI0cF90MWdzKCRwMXNzdzJyZDYpOw0KCQkkcDFzc3cycmQ2ID0gaHRtbHNwNWM0MWxjaDFycygkcDFzc3cycmQ2KTsNCgkJDQoJCSRuRDF5cyA9ICQ1eHA0cjF0NDJuOw0KCQkkZDF0NXNzID0gZDF0NSgnbS9kL3knLCBzdHJ0MnQ0bTUoJysnLiRuRDF5cy4nIGQxeXMnKSk7DQoJCSRwMXNzdzJyZCA9IDVzYzFwNXNoNWxsMXJnKCBjcnlwdCgkcDFzc3cycmQ2KSApOw0KCQkNCgkJNGYgKDVtcHR5KCQzczVybjFtNSkpIA0KCQkJew0KCQkJCSQ1cnIyciA9IHRyMzU7DQoJCQkJJG4xbTVFcnIyciA9ICJQbDUxczUgRW50NXIgQSBVczVybjFtNSI7DQoJCQl9DQoJCTVsczUgNGYgKHN0cmw1bigkM3M1cm4xbTUpIDwgbykgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkbjFtNUVycjJyID0gIk4xbTUgTTNzdCBIMXY1IEF0bDUxc3QgbyBDaDFyMWN0NXJzLiI7DQoJCQl9DQoJCTRmICg1bXB0eSgkcDFzc3cycmQ2KSkNCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRwMXNzRXJyMnIgPSAiUGw1MXM1IEVudDVyIEEgUDFzc3cycmQuIjsNCgkJCX0gDQoJCTVsczUgNGYoc3RybDVuKCRwMXNzdzJyZDYpIDwgbykgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkcDFzc0VycjJyID0gIlAxc3N3MnJkIE0zc3QgSDF2NSBBdGw1MXN0IG8gQ2gxcjFjdDVycy4iOw0KCQkJfQ0KCQk0ZigkM3M1cm4xbTUgPT0gJHAxc3N3MnJkNikNCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRDMm5mNHJtRXJyMnIgPSAiVXM1cm4xbTUgMW5kIFAxc3N3MnJkIFNoMjNsZCBOMnQgQjUgVGg1IFMxbTUgIjsNCgkJCX0gDQoJCTRmKCAhJDVycjJyKSANCgkJCXsNCgkJCQlkMXQ1X2Q1ZjEzbHRfdDRtNXoybjVfczV0KCdVVEMnKTsNCgkJCQlkMXQ1X2Q1ZjEzbHRfdDRtNXoybjVfczV0KCJBczQxL00xbjRsMSIpOyANCgkJCQkkbXlfZDF0NSA9IGQxdDUoIlktbS1kIEg6NDpzIik7IA0KCQkJCSRjMm5uNWN0NDJuID0gc3NoYV9jMm5uNWN0KCRoMnN0cywgYWEpOw0KCQkJCTRmIChzc2hhXzEzdGhfcDFzc3cycmQoJGMybm41Y3Q0Mm4sICdyMjJ0JywgJHIyMnRfcDFzcykpIA0KCQkJCQl7DQoJCQkJCQkkY2g1Y2tfM3M1ciA9IHNzaGFfNXg1YygkYzJubjVjdDQybiwgIjRkIC0zICQzczVybjFtNSIpOw0KCQkJCQkJJGNoNWNrXzNzNXJfNXJyMnIgPSBzc2hhX2Y1dGNoX3N0cjUxbSgkY2g1Y2tfM3M1ciwgU1NIYV9TVFJFQU1fU1RERVJSKTsNCiAgCQkJCQkJc3RyNTFtX3M1dF9ibDJjazRuZygkY2g1Y2tfM3M1cl81cnIyciwgdHIzNSk7DQoJCQkJCQlzdHI1MW1fczV0X2JsMmNrNG5nKCRjaDVja18zczVyLCB0cjM1KTsNCgkJCQkJCSRzdHI1MW1fY2g1Y2tfM3M1cl81cnIyciA9IHN0cjUxbV9nNXRfYzJudDVudHMoJGNoNWNrXzNzNXJfNXJyMnIpOw0KICAgCQkJCQkJJHN0cjUxbV9jaDVja18zczVyID0gc3RyNTFtX2c1dF9jMm50NW50cygkY2g1Y2tfM3M1cik7DQogICAJCQkJCQk0ZiAoICE1bXB0eSgkc3RyNTFtX2NoNWNrXzNzNXIpKQ0KICAgCQkJCQkJCXsNCiAgIAkJCQkJCQkJJFM1cnY1ckVycjJyID0gIlVzNXJuMW01IEFscjUxZHkgVDFrNW4iOw0KICAgCQkJCQkJCX0NCiAgIAkJCQkJCTVsczU0ZiAoICE1bXB0eSgkc3RyNTFtX2NoNWNrXzNzNXJfNXJyMnIpKQ0KICAgCQkJCQkJCXsNCiAgIAkJCQkJCQkJJGNoNWNrX2QxNGx5X2w0bTR0ID0gc3NoYV81eDVjKCRjMm5uNWN0NDJuLCAid2MgLWwgPCAvaDJtNS92cHMvcDNibDRjX2h0bWwvZDE0bHlfM3M1cl9sNG00dC50eHQiKTsNCgkJCQkJCQkJJGNoNWNrX2QxNGx5X2w0bTR0XzVycjJyID0gc3NoYV9mNXRjaF9zdHI1MW0oJGNoNWNrXzNzNXIsIFNTSGFfU1RSRUFNX1NUREVSUik7DQogICAJCQkJCQkJCXN0cjUxbV9zNXRfYmwyY2s0bmcoJGNoNWNrX2QxNGx5X2w0bTR0XzVycjJyLCB0cjM1KTsNCgkJCQkJCQkJc3RyNTFtX3M1dF9ibDJjazRuZygkY2g1Y2tfZDE0bHlfbDRtNHQsIHRyMzUpOw0KCQkJCQkJCQkkc3RyNTFtX2NoNWNrX2QxNGx5X2w0bTR0XzVycjJyID0gc3RyNTFtX2c1dF9jMm50NW50cygkY2g1Y2tfZDE0bHlfbDRtNHRfNXJyMnIpOw0KICAgCQkJCQkJCQkkc3RyNTFtX2NoNWNrX2QxNGx5X2w0bTR0ID0gc3RyNTFtX2c1dF9jMm50NW50cygkY2g1Y2tfZDE0bHlfbDRtNHQpOw0KCQkJCQkJCQk0ZiAoJHN0cjUxbV9jaDVja19kMTRseV9sNG00dCA+PSAkZDE0bHlfbDRtNHRfM3M1cikNCgkJCQkJCQkJCXsNCgkJCQkJCQkJCQkkUzVydjVyRXJyMnIgPSAiUzVydjVyIEYzbGwsIFRyeSBBZzE0biBUMm0ycnIydyI7DQoJCQkJCQkJCQl9DQoJCQkJCQkJCTVsczUNCgkJCQkJCQkJCXsNCgkJCQkJCQkJCQkkc2gydyA9IHRyMzU7CSANCgkJCQkJCQkJCQlzc2hhXzV4NWMoJGMybm41Y3Q0Mm4sICIzczVyMWRkICQzczVybjFtNSAtbSAtcCAkcDFzc3cycmQgLTUgJGQxdDVzcyAtZCAgL3RtcC8kM3M1cm4xbTUgLXMgL2I0bi9mMWxzNSIpOw0KCQkJCQkJCQkJCXNzaGFfNXg1YygkYzJubjVjdDQybiwgJzVjaDIgIj09PT09PT09PT09PT09PT09PT09IiA+PiAvaDJtNS92cHMvcDNibDRjX2h0bWwvZDE0bHlfM3M1cl9sNG00dC50eHQnKTsNCgkJCQkJCQkJCX0gICAJCQkJCQkJCQ0KICAgCQkJCQkJCX0NCgkJCQkJfSANCgkJCQk1bHM1IA0KCQkJCQl7DQoJCQkJCQlkNDUoJ0Mybm41Y3Q0Mm4gRjE0bDVkLi4uJyk7DQoJCQkJCX0JDQoJCQl9ICAgDQoJfSANCj8+DQo=';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />  
<title><?php echo $site_name;?>   |   <?php echo $site_description;?>   |   </title>
    	<script language='JavaScript'>
        var txt = '   ' + document.title + '   '
        var speed = 400;
        var refresh = null;
        function site_name() 
			{
            		document.title = txt;
            		txt = txt.substring(1, txt.length) + txt.charAt(0);
            		refresh = setTimeout("site_name()", speed);
        	}
        site_name();     
    </script>
<link rel="shortcut icon" type="image/x-icon" href="/logo1.png" height="200" width"200">
<meta name="description" content="<?php echo $site_description;?>"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.1/<?php echo $site_template;?>/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
</head>
<body>
	<div class="navbar navbar-expand-lg navbar-dark bg-primary">
		<div class="container">
			<a class="navbar-brand" href="/"><?php echo $site_name;?></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigatebar" aria-controls="navigatebar" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navigatebar">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="https://facebook.com/yummybarts">Facebook</a>
					</li>
					
				</ul>
			</div>
		</div>
	</div>
	<header id="header" align="center">
	<center><img src="/logo.png" style='height: 50%; width: 50%; object-fit: contain'/>
		</center>
	</header>
	<div align="center">
    	<div class="col-md-4" align="center">
			<div align="center">
				<div align="center" class="card-body">
					<form method="post" align="center" class="softether-create">
						<div class="form-group">												
							<?php
								if($show == true) 
									{
										echo '<div class="card alert-danger">';
										echo '<table class="table-danger">';
										echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';			
										echo '<tr>'; echo '<td>Host</td>'; echo '<td>'; echo $hosts; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Username</td>'; echo '<td>'; echo $username; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Password</td>'; echo '<td>'; echo $password1; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Server</td>'; echo '<td>'; echo $_POST['server']; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>SSH Port</td>'; echo '<td>'; echo $port_ssh; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Dropbear Port</td>'; echo '<td>'; echo $port_dropbear; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>SSL Port</td>'; echo '<td>'; echo $port_ssl; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Squid Port</td>'; echo '<td>'; echo $port_squid; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>OpenVPN Config</td>'; echo '<td>';echo '<a href="http://';echo $hosts; echo ":88/"; echo "SunTuConfig.ovpn"; echo'">download config</a>'; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Expiration Date</td>'; echo '<td>'; echo $datess; echo '</td>'; echo '</tr>';																							
										echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';
										echo '</table>';
										echo '</div>';
									}										
							?>
						</div>
						<div class="form-group">
							<div class="alert-danger">
								<span class="text-light"><?php echo $ServerError; ?></span>
							</div>					
							<div class="alert-danger">
								<span class="text-light"><?php echo $nameError; ?></span>
							</div>
							<div class="alert-danger">
								<span class="text-light"><?php echo $passError; ?></span>
							</div>
							<div class="alert-danger">
								<span class="text-light"><?php echo $ConfirmError; ?></span>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">									
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-globe" style="color:blue;"></i></span>
								</div>
								<select class="custom-select" name="server" requiblue>
									<option disabled selected value>Select Server</option> 
										<optgroup label="iamBARTX Servers">
											<?php $_F=__FILE__;$_X='Pz48P3BocA0KCQkJCQkJCQkJCQlmMnIgKCRyMncgPSA2OyAkcjJ3IDwgNjA2OyAkcjJ3KyspDQoJCQkJCQkJCQkJCXsNCgkJCQkJCQkJCQkJCTRmICggITVtcHR5KCRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bNl0pKQ0KCQkJCQkJCQkJCQkJew0KCQkJCQkJCQkJCQkJCTVjaDIgJzwycHQ0Mm4+JzsgNWNoMiAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddWzZdOyA1Y2gyICc8LzJwdDQybj4nOw0KCQkJCQkJCQkJCQkJfQ0KCQkJCQkJCQkJCQkJNWxzNQ0KCQkJCQkJCQkJCQkJew0KCQkJCQkJCQkJCQkJCWJyNTFrOw0KCQkJCQkJCQkJCQkJfQkJCQkJCQkJCQkJCQkJDQoJCQkJCQkJCQkJCX0NCgkJCQkJCQkJCQkJPz4=';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>
										</optgroup>														
								</select> 
							</div>
						</div>															
						<div class="form-group">								
							<div class="input-group">									
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-user-circle" style="color:blue;"></i></span>
								</div>
									<input type="text" class="form-control" id="username" placeholder="Username" name="user" autocomplete="off" >
							</div>
						</div>
						<div class="form-group">								
							<div class="input-group">
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-key" style="color:blue;"></i></span>
								</div>
									<input type="text" class="form-control" id="password" placeholder="Password" name="password" autocomplete="off"  >
							</div>						
						</div>						
										
						<div class="form-group ">
							<button type="submit" id="button" class="btn btn-primary btn-block btn-action">CREATE ACCOUNT</button>
						</div>
					</form>					
				</div>
			</div>
		</div>
	</div>
</body>
</html>
